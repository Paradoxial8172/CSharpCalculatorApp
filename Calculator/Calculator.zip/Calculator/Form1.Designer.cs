﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OutputTextBox = new TextBox();
            Button_7 = new Button();
            Button_8 = new Button();
            Button_9 = new Button();
            Button_4 = new Button();
            Button_5 = new Button();
            Button_6 = new Button();
            Button_1 = new Button();
            Button_2 = new Button();
            Button_3 = new Button();
            Button_Decimal = new Button();
            Button_0 = new Button();
            EvaluateButton = new Button();
            BackButton = new Button();
            ButtonAdd = new Button();
            Button_Subtract = new Button();
            Button_Multiply = new Button();
            Button_Divide = new Button();
            ClearButton = new Button();
            LeftParaButton = new Button();
            RightParaButton = new Button();
            SuspendLayout();
            // 
            // OutputTextBox
            // 
            OutputTextBox.BorderStyle = BorderStyle.None;
            OutputTextBox.Enabled = false;
            OutputTextBox.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            OutputTextBox.Location = new Point(18, 12);
            OutputTextBox.Name = "OutputTextBox";
            OutputTextBox.Size = new Size(218, 32);
            OutputTextBox.TabIndex = 0;
            // 
            // Button_7
            // 
            Button_7.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_7.Location = new Point(18, 106);
            Button_7.Name = "Button_7";
            Button_7.Size = new Size(50, 50);
            Button_7.TabIndex = 1;
            Button_7.Text = "7";
            Button_7.UseVisualStyleBackColor = true;
            Button_7.Click += Button_7_Click;
            // 
            // Button_8
            // 
            Button_8.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_8.Location = new Point(74, 106);
            Button_8.Name = "Button_8";
            Button_8.Size = new Size(50, 50);
            Button_8.TabIndex = 2;
            Button_8.Text = "8";
            Button_8.UseVisualStyleBackColor = true;
            Button_8.Click += Button_8_Click;
            // 
            // Button_9
            // 
            Button_9.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_9.Location = new Point(130, 106);
            Button_9.Name = "Button_9";
            Button_9.Size = new Size(50, 50);
            Button_9.TabIndex = 3;
            Button_9.Text = "9";
            Button_9.UseVisualStyleBackColor = true;
            Button_9.Click += Button_9_Click;
            // 
            // Button_4
            // 
            Button_4.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_4.Location = new Point(18, 162);
            Button_4.Name = "Button_4";
            Button_4.Size = new Size(50, 50);
            Button_4.TabIndex = 4;
            Button_4.Text = "4";
            Button_4.UseVisualStyleBackColor = true;
            Button_4.Click += Button_4_Click;
            // 
            // Button_5
            // 
            Button_5.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_5.Location = new Point(74, 162);
            Button_5.Name = "Button_5";
            Button_5.Size = new Size(50, 50);
            Button_5.TabIndex = 5;
            Button_5.Text = "5";
            Button_5.UseVisualStyleBackColor = true;
            Button_5.Click += Button_5_Click;
            // 
            // Button_6
            // 
            Button_6.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_6.Location = new Point(130, 162);
            Button_6.Name = "Button_6";
            Button_6.Size = new Size(50, 50);
            Button_6.TabIndex = 6;
            Button_6.Text = "6";
            Button_6.UseVisualStyleBackColor = true;
            Button_6.Click += Button_6_Click;
            // 
            // Button_1
            // 
            Button_1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_1.Location = new Point(18, 218);
            Button_1.Name = "Button_1";
            Button_1.Size = new Size(50, 50);
            Button_1.TabIndex = 7;
            Button_1.Text = "1";
            Button_1.UseVisualStyleBackColor = true;
            Button_1.Click += Button_1_Click;
            // 
            // Button_2
            // 
            Button_2.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_2.Location = new Point(74, 218);
            Button_2.Name = "Button_2";
            Button_2.Size = new Size(50, 50);
            Button_2.TabIndex = 8;
            Button_2.Text = "2";
            Button_2.UseVisualStyleBackColor = true;
            Button_2.Click += Button_2_Click;
            // 
            // Button_3
            // 
            Button_3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_3.Location = new Point(130, 218);
            Button_3.Name = "Button_3";
            Button_3.Size = new Size(50, 50);
            Button_3.TabIndex = 9;
            Button_3.Text = "3";
            Button_3.UseVisualStyleBackColor = true;
            Button_3.Click += Button_3_Click;
            // 
            // Button_Decimal
            // 
            Button_Decimal.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_Decimal.Location = new Point(18, 274);
            Button_Decimal.Name = "Button_Decimal";
            Button_Decimal.Size = new Size(50, 50);
            Button_Decimal.TabIndex = 10;
            Button_Decimal.Text = ".";
            Button_Decimal.UseVisualStyleBackColor = true;
            Button_Decimal.Click += Button_Decimal_Click;
            // 
            // Button_0
            // 
            Button_0.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_0.Location = new Point(74, 274);
            Button_0.Name = "Button_0";
            Button_0.Size = new Size(50, 50);
            Button_0.TabIndex = 11;
            Button_0.Text = "0";
            Button_0.UseVisualStyleBackColor = true;
            Button_0.Click += Button_0_Click;
            // 
            // EvaluateButton
            // 
            EvaluateButton.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            EvaluateButton.Location = new Point(130, 274);
            EvaluateButton.Name = "EvaluateButton";
            EvaluateButton.Size = new Size(50, 50);
            EvaluateButton.TabIndex = 12;
            EvaluateButton.Text = "=";
            EvaluateButton.UseVisualStyleBackColor = true;
            EvaluateButton.Click += EvaluateButton_Click;
            // 
            // BackButton
            // 
            BackButton.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            BackButton.Location = new Point(186, 50);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(50, 50);
            BackButton.TabIndex = 13;
            BackButton.Text = "←";
            BackButton.UseVisualStyleBackColor = true;
            BackButton.Click += BackButton_Click;
            // 
            // ButtonAdd
            // 
            ButtonAdd.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            ButtonAdd.Location = new Point(186, 106);
            ButtonAdd.Name = "ButtonAdd";
            ButtonAdd.Size = new Size(50, 50);
            ButtonAdd.TabIndex = 14;
            ButtonAdd.Text = "+";
            ButtonAdd.UseVisualStyleBackColor = true;
            ButtonAdd.Click += ButtonAdd_Click;
            // 
            // Button_Subtract
            // 
            Button_Subtract.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_Subtract.Location = new Point(186, 162);
            Button_Subtract.Name = "Button_Subtract";
            Button_Subtract.Size = new Size(50, 50);
            Button_Subtract.TabIndex = 15;
            Button_Subtract.Text = "-";
            Button_Subtract.UseVisualStyleBackColor = true;
            Button_Subtract.Click += Button_Subtract_Click;
            // 
            // Button_Multiply
            // 
            Button_Multiply.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            Button_Multiply.Location = new Point(186, 218);
            Button_Multiply.Name = "Button_Multiply";
            Button_Multiply.Size = new Size(50, 50);
            Button_Multiply.TabIndex = 16;
            Button_Multiply.Text = "X";
            Button_Multiply.UseVisualStyleBackColor = true;
            Button_Multiply.Click += Button_Multiply_Click;
            // 
            // Button_Divide
            // 
            Button_Divide.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            Button_Divide.Location = new Point(186, 274);
            Button_Divide.Name = "Button_Divide";
            Button_Divide.Size = new Size(50, 50);
            Button_Divide.TabIndex = 17;
            Button_Divide.Text = "÷";
            Button_Divide.UseVisualStyleBackColor = true;
            Button_Divide.Click += Button_Divide_Click;
            // 
            // ClearButton
            // 
            ClearButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            ClearButton.Location = new Point(18, 50);
            ClearButton.Name = "ClearButton";
            ClearButton.Size = new Size(50, 50);
            ClearButton.TabIndex = 18;
            ClearButton.Text = "CE";
            ClearButton.UseVisualStyleBackColor = true;
            ClearButton.Click += ClearButton_Click;
            // 
            // LeftParaButton
            // 
            LeftParaButton.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            LeftParaButton.Location = new Point(74, 50);
            LeftParaButton.Name = "LeftParaButton";
            LeftParaButton.Size = new Size(50, 50);
            LeftParaButton.TabIndex = 19;
            LeftParaButton.Text = "(";
            LeftParaButton.UseVisualStyleBackColor = true;
            LeftParaButton.Click += LeftParaButton_Click;
            // 
            // RightParaButton
            // 
            RightParaButton.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            RightParaButton.Location = new Point(130, 50);
            RightParaButton.Name = "RightParaButton";
            RightParaButton.Size = new Size(50, 50);
            RightParaButton.TabIndex = 20;
            RightParaButton.Text = ")";
            RightParaButton.UseVisualStyleBackColor = true;
            RightParaButton.Click += RightParaButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(254, 336);
            Controls.Add(RightParaButton);
            Controls.Add(LeftParaButton);
            Controls.Add(ClearButton);
            Controls.Add(Button_Divide);
            Controls.Add(Button_Multiply);
            Controls.Add(Button_Subtract);
            Controls.Add(ButtonAdd);
            Controls.Add(BackButton);
            Controls.Add(EvaluateButton);
            Controls.Add(Button_0);
            Controls.Add(Button_Decimal);
            Controls.Add(Button_3);
            Controls.Add(Button_2);
            Controls.Add(Button_1);
            Controls.Add(Button_6);
            Controls.Add(Button_5);
            Controls.Add(Button_4);
            Controls.Add(Button_9);
            Controls.Add(Button_8);
            Controls.Add(Button_7);
            Controls.Add(OutputTextBox);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox OutputTextBox;
        private Button Button_7;
        private Button Button_8;
        private Button Button_9;
        private Button Button_4;
        private Button Button_5;
        private Button Button_6;
        private Button Button_1;
        private Button Button_2;
        private Button Button_3;
        private Button Button_Decimal;
        private Button Button_0;
        private Button EvaluateButton;
        private Button BackButton;
        private Button ButtonAdd;
        private Button Button_Subtract;
        private Button Button_Multiply;
        private Button Button_Divide;
        private Button ClearButton;
        private Button LeftParaButton;
        private Button RightParaButton;
    }
}